CKEDITOR.editorConfig = function(config) {
  config.language = 'ja';
};
